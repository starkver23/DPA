package uk.ac.bham.codeclassroom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GeneratedApplication {
    public static void main(String[] args) {
        SpringApplication.run(GeneratedApplication.class, args);
    }
}
